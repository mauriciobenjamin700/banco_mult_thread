# banco_mult_thread
Este protótipo ilustra como seria um sistema bancário
a interface grafica foi feita com PyQt5 
o banco de dados usado foi MySQL
e a linguagem central foi python
