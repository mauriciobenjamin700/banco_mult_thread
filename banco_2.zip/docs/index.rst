.. Banco documentation master file, created by
   sphinx-quickstart on Thu Feb 16 08:21:51 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Banco's documentation!
=================================
.. automodule:: main
   :members:
.. automodule:: servidor_final
   :members:
.. automodule:: banco
   :members:
.. automodule:: tela_inicial
   :members:
.. automodule:: tela_cadastro
   :members:
.. automodule:: tela_login
   :members:
.. automodule:: tela_geral
   :members:
.. automodule:: tela_deposito
   :members:
.. automodule:: tela_saque
   :members:
.. automodule:: tela_transferencia
   :members:
.. automodule:: tela_historico
   :members:

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
